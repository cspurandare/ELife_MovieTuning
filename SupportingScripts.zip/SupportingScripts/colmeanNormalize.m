function [ output_args ] = colmeanNormalize( input_args )
%Take mean by columns, and normalize by that
t1=repmat(nanmean(input_args,2),1,size(input_args,2));
output_args=(input_args)./t1;

end

