function [RunFreeID] = GetRunFreeIDs(RV,RVCut,TBins,TCutoff)
%Given the running speed and cutoff for RV as well as the runfree data
%cutoff, create boolean of data which is clean and far away from running
%epochs
SMO=0;%I am smoothing it outside

C_TBins=center(TBins);TID=1:length(C_TBins);
RVSmo=jmm_smooth_1d_cor(RV,SMO,1);

RVBool=find(abs(RVSmo)>RVCut);RVBool=[1 RVBool length(C_TBins)];RunStart=C_TBins(RVBool);
tempID=(nearestpoint(1:length(C_TBins),RVBool,'next'));
tempID(isnan(tempID))=length(C_TBins);
RVFuture=RunStart(tempID)-C_TBins;

tempID=(nearestpoint(1:length(C_TBins),RVBool,'previous'));
tempID(isnan(tempID))=1;
RVPast=C_TBins-RunStart(tempID);

RunFreeID=RVPast>TCutoff & RVFuture>TCutoff;
end

