function [ScP,TStart,TEnd,ST,SI,TBins,RunFreeID,RunForW,RV,EProp,EProp2] ...
    = Allen_VVDot_Get_RunBehavior_v2(fileName,delT,TCutoff,RVCut)
%Give me the session number and the unit, and I will plot the VVDot space scatter

%%Create the experiment outline
EData=Create_ExperimentEpochs_AllenData2(fileName,'spontaneous_presentations');
%%Get the running behavior
Beh=CreateBehAllenData2(fileName);
Beh.RunV2=(jmm_smooth_1d_cor(Beh.RunV2,30,1))';%Around 1 second of smoothing
TStart=EData.Start( strcmp(EData.Name,'spontaneous'));
TEnd=EData.End( strcmp(EData.Name,'spontaneous'));
[~,IDBlock]=max(TEnd-TStart);
TStart=TStart(IDBlock);
TEnd=TEnd(IDBlock);
TBins=TStart:delT:TEnd;
RV=interp1(Beh.EyeT,Beh.RunV2,center(TBins));

EV=interp1(Beh.EyeT,Beh.EyeV,center(TBins));
ESize=interp1(Beh.EyeT,Beh.EyeEllipse(:,1:2),center(TBins));
EP=interp1(Beh.EyeT,Beh.ScreenPos2,center(TBins));
EV_x=diff(jmm_smooth_1d_cor(Beh.ScreenPos2(:,1),10,1))'./diff(Beh.EyeT);EV_x=[EV_x(1);EV_x];
EV_y=diff(jmm_smooth_1d_cor(Beh.ScreenPos2(:,2),10,1))'./diff(Beh.EyeT);EV_y=[EV_y(1);EV_y];
EV2(:,1)=interp1(Beh.EyeT,EV_x,center(TBins));
EV2(:,2)=interp1(Beh.EyeT,EV_y,center(TBins));
ESize=ESize(:,1).*ESize(:,2);
RunFreeID=GetRunFreeIDs(RV,RVCut,TBins,TCutoff);
RunForW=RV>0;
Acc=jmm_smooth_1d_cor(diff(RV)./diff(center(TBins)),30,1);
AC=interp1(center(center(TBins)),Acc,center(TBins));
ScP=[RV(~RunFreeID & RunForW); AC(~RunFreeID & RunForW)]';
EProp=[ESize(~RunFreeID & RunForW) EV(~RunFreeID & RunForW)' EP(~RunFreeID & RunForW,:) EV2(~RunFreeID & RunForW,:)];
EProp2=[ESize(RunFreeID) EV(RunFreeID)' EP(RunFreeID,:) EV2(RunFreeID,:)];
ST = h5read(fileName, '/units/spike_times');%Time of spikes
SI =double( h5read(fileName, '/units/spike_times_index'));% What unit does this spike belong to


end
