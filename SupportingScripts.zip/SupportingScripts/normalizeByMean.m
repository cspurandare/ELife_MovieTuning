function [ outvec ] = normalizeByMean( vector )
%Just substract mean and divide by the maxima

outvec=(vector)/nanmean(vector);

end
