function [ out,binsC,out2,FROut ] = depHist( TobeBinned,binCreator,binData,binType,percIn,Function,Smo,Type,DT )
%This function is to be used in the case when we have say 2 time dependent
%variables. Say Rat speed and pillar angle, and we want to find the mean
%speed of the rat based on 30 bins of pillar angle. Then TobeBinned is the
%rat speed, binCreator is the pillar angle. numBins is the number of bins
%needed. Function could be something like
%1. Mean speed for all the time instances when the pillar was in the bin
%specified
%2. Percent datapoints. This is the same as above, normalized by occupancy
%in each bins(in terms of number of datapoints)
if length(binData)==1
    out=NaN(binData,1);
    out2=NaN(binData,1);
    binsC=NaN(binData,1);
else
    out=NaN(length(binData)-1,1);
    out2=NaN(length(binData)-1,1);
    binsC=NaN(length(binData)-1,1);
end
if length(TobeBinned)==length(binCreator)
    if  length(binData)==1
        if strcmp(binType,'eqOccu')
            binE=prctile(binCreator,linspace(percIn,100-percIn,binData+1));
        else
            binE=linspace(prctile(binCreator,percIn),prctile(binCreator,100-percIn),binData+1);
        end
    else
        binE=binData;
    end
    binsC=(binE(1:end-1)+binE(2:end))*0.5;
    if  length(binData)==1
        for i=1:binData-1
            try
            out(i)=Function(TobeBinned(binCreator>=binE(i) & binCreator<binE(i+1)));
            catch
                out(i)=nan;
            end
            out2(i)=sum(binCreator>=binE(i) & binCreator<binE(i+1));%/length(binCreator);
        end
    else
        for i=1:length(binData)-1
            try
            out(i)=Function(TobeBinned(binCreator>=binE(i) & binCreator<binE(i+1)));
            catch
                out(i)=nan;
            end
            out2(i)=sum(binCreator>=binE(i) & binCreator<binE(i+1));%;/length(binCreator);
        end
    end
end
FROut=NaN;
if nargin>7
    if strcmp(Type,'circ')
        FROut=jmm_smooth_1d_cor_circ(out,Smo,1)./jmm_smooth_1d_cor_circ(out2,Smo,1)*DT;
        out=jmm_smooth_1d_cor_circ(out,Smo,1);
    else
        FROut=jmm_smooth_1d_cor(out,Smo,1)./jmm_smooth_1d_cor(out2,Smo,1)*DT;
        out=jmm_smooth_1d_cor(out,Smo,1);
    end
end
end

