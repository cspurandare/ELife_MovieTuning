function [ output_args ] = plot45Line( color )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
a=xlim;
b=ylim;
line([a(1) a(2)],[b(1) b(2)],'Color',color,'linewidth',1,'linestyle','--');

end

