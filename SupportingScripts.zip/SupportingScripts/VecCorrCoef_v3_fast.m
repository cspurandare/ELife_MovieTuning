function [ O ] = VecCorrCoef_v3_fast( E1,E2 )
%This function assumes that no nans or infs are being sent in, unlike prior
%functions which used the corrcoefwithnan thingy which removed nans
%seperately
[sz1,sz2]=size(E1);
m1=nanmean(E1);
m1d=nanmean(E1');
s1=nanstd(E1);
s1d=nanstd(E1');

m2=nanmean(E2);
m2d=nanmean(E2');
s2=nanstd(E2);
s2d=nanstd(E2');

E1=(E1-repmat(m1,sz1,1))./repmat(s1,sz1,1)/sqrt(sz1-1);
E2=(E2-repmat(m2,sz1,1))./repmat(s2,sz1,1)/sqrt(sz1-1);
O=E1'*E2;
end

