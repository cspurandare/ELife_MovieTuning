function [ outM] = colsmoothChinmay_Circ( inMatrix,SMO)
%Take mean by columns, and normalize by that
outM=inMatrix;
s=size(inMatrix,1);

for i=1:s
    outM(i,:)=jmm_smooth_1d_cor_circ(inMatrix(i,:),SMO,1);
end
end

