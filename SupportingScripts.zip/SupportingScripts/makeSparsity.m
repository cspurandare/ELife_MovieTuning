function [total] = makeSparsity(amps,junk)       
    %[total] = makeSparsity(amps)  
    amps=amps(:);
    total = 1-((nansum(amps).^2)./(nansum(amps.^2)))/length(amps(~isnan(amps)));
end