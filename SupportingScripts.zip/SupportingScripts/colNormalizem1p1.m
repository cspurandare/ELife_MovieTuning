function [ output_args ] = colNormalizem1p1( input_args )
%Take mean by columns, and normalize to be between minus 1 plus 1
output_args=input_args;
s=size(input_args,1);
for i=1:s
output_args(i,:)=normalize_m1p1(input_args(i,:));
end
end

