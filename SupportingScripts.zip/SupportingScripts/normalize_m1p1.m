function [ output_args ] = normalize_m1p1( input_args )
%Simply just normalize between plus minus 1


output_args=2*normalize01(input_args)-1;
end

