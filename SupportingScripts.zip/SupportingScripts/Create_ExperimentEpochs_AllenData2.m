function [ExpData] = Create_ExperimentEpochs_AllenData2(fileName,StimType)
%UNTITLED To avoid too much data trash neurons which belong to grey or none
%------------------------------------------------------------------------------------
ExpData.Name = h5read(fileName, ['/intervals/' StimType '/stimulus_name']);
ExpData.Start = h5read(fileName, ['/intervals/' StimType '/start_time']);
ExpData.End = h5read(fileName, ['/intervals/' StimType '/stop_time']);
ExpData.Time = h5read(fileName, ['/intervals/' StimType '/timeseries']);
try
    ExpData.Ind = h5read(fileName, ['/intervals/' StimType '/stimulus_index']);
    ExpData.XPos = h5read(fileName, ['/intervals/' StimType '/x_position']);
    ExpData.YPos = h5read(fileName, ['/intervals/' StimType '/y_position']);
catch
end
try
    ExpData.Orientation = h5read(fileName,['/intervals/' StimType '/orientation']);
    ExpData.TempFq = h5read(fileName, ['/intervals/' StimType '/temporal_frequency']);
    ExpData.Contrast = h5read(fileName, ['/intervals/' StimType '/contrast']);
catch
end
try
    ExpData.FrameID= h5read(fileName, ['/intervals/' StimType '/id']);
    ExpData.Frame= h5read(fileName, ['/intervals/' StimType '/frame']);
catch
end
%ExpData.Dir= h5read(fileName, '/intervals/epochs/Dir');
%ExpData.Speed= h5read(fileName, '/intervals/epochs/Speed');
end