function [ Rate ] = GetExpectedRate1D( tc,binX,XInfo )
%Given a time vector and rat exploring some sort of 1D frame, and this led
%to some overall average tuning curve tc, I want to go back through time
%and create a vector of the expected firing rate at each point, based on
%where he was. This expected value would be the mean rate in the bin
%closest to the rat's current XInfo . 
Rate=NaN(size(XInfo));
IX=nearestpoint(XInfo,binX);%Closest bin center at each point
Good= ~isnan(XInfo);
idx=sub2ind(size(tc),IX(Good));
Rate(Good)=tc(idx);

end

