function [a,b] = PartialCorrwithNan(Matrix)
%USe only the rows with no nans
t1=sum(isnan(Matrix)' ) + sum(isinf(Matrix)');
Matrix2=Matrix(t1==0,:);
[a,b]=partialcorr(Matrix2);
%a=partialcorr(Matrix2);
%b=nan;
end

