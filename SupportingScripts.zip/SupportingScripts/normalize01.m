function [ output_args ] = normalize01( input_args )
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here
if nanmax(input_args)~=nanmin(input_args)
output_args=(input_args-nanmin(input_args))/(nanmax(input_args)-nanmin(input_args));
else
    output_args=input_args/nanmin(input_args);
end
end

