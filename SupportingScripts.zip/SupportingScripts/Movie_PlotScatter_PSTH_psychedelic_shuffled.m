function  [L1,L2]=Movie_PlotScatter_PSTH_psychedelic_shuffled(UnitID,FileName,TCutoff,RVCut,FrameBins,FR_act,FR_shf_mean,FR_shf_std,LocIN,LabelBool,CLR_current,UseAllData,ShuffledFrameIDs)
%For a given cell, plot the scatter of spikes and the FR actual as well as
%the shuffled one
ClrMP=cool(900);
if nargin>12
    [~,~,~,ST,SI,TBins,RunFreeID,~,~,FrameID]=...
        Allen_VVDot_Get_RunBehavior_Movies_shuffled([FileName]...
        ,TCutoff,RVCut,ShuffledFrameIDs);
else
    [~,~,~,ST,SI,TBins,RunFreeID,~,~,FrameID]=...
        Allen_VVDot_Get_RunBehavior_Movies_shuffled([FileName]...
        ,TCutoff,RVCut);
end
RepCount=ceil((1:18000)/900);
RunFreeID=RunFreeID([1:9000 9002:end]);
if UseAllData
    RunFreeID=true(size(RunFreeID));
end
FrameIDsta=FrameID(RunFreeID);
RepCountsta=RepCount(RunFreeID);
TimeCenter=center(TBins);
TimeCenter=TimeCenter([1:9000 9002:end]);
TimeCentersta=TimeCenter(RunFreeID);
if UnitID>1
    STCurrent=ST(SI((UnitID-1))+1:SI((UnitID)));%When does this particular neuron fire
else
    STCurrent=ST(1:SI(1));%When does this particular neuron fire
end

STCurrent=STCurrent(isbetween(STCurrent,TBins(1),TBins(9001)) | isbetween(STCurrent,TBins(9002),TBins(end)));
STCurrent=STCurrent(RunFreeID(nearestpoint(STCurrent,TimeCenter)) );
SpID=nearestpoint(STCurrent,TimeCentersta);

L1=subplot('Position',[LocIN(1),LocIN(2)+LocIN(4)/2+0.01,LocIN(3) LocIN(4)/2]);
if UseAllData
else
    plot(FrameIDsta,RepCountsta,'.','color',[0.9 0.9 0.9],'markersize',0.01);
end
hold on
if nanmean(FR_act)<4
    
    scatter(FrameIDsta(SpID),RepCountsta(SpID),4,FrameIDsta(SpID),'filled')
    colormap(gca,ClrMP)
else
    scatter(FrameIDsta(SpID),RepCountsta(SpID),4,FrameIDsta(SpID),'filled')
    colormap(gca,ClrMP)
end
axis tight
if LabelBool
    ylabel('Trial #');
    
end
%xticks([400 800])
ylim([0 20.5])
xticks([])
yticks([0 20])

box off;
try
    L2=subplot('Position',[LocIN(1),LocIN(2),LocIN(3) LocIN(4)/2]);
    plot(center(FrameBins),FR_act,'color',CLR_current);
    hold on
    shadedErrorBar(center(FrameBins),jmm_smooth_1d_cor(FR_shf_mean,2,1),...
        2*jmm_smooth_1d_cor(FR_shf_std,2,1),[0.3 0.3 0.3],1);
    if LabelBool
        
        xlabel('Scrambled frame #')
        ylabel('FR (sp/sec)');
    end
    axis tight;box off
    xticks([400 800])
    ylim([0 inf])
    try
        yticks([0 floor(nanmax(FR_act)*0.75)])
    catch
        yticks([0 1])
    end
    
catch
end
ax=gca;ax.YAxis.Color = CLR_current;
end

