function [ Vel,VelSigned ,VelSigned2] = RecreateSpeed( X,Y,T,SMO )
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
if nargin<4
    SMO=2;
end
Vel=1e6*(([sqrt(diff(jmm_smooth_1d_cor(X,SMO,1)).^2 + diff(jmm_smooth_1d_cor(Y,SMO,1)).^2);]))'./ ...
    [jmm_smooth_1d_cor(diff(T),SMO,1)']; 

Vel=[Vel(1);Vel];
VelSigned=sign([1 diff(jmm_smooth_1d_cor(X,SMO,1))])'.*Vel;
VelSigned2=sign([1 diff(jmm_smooth_1d_cor(Y,SMO,1))])'.*Vel;
end

