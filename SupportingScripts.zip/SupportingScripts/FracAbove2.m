function [ output_args ] = FracAbove2( input_args )
%Simple function finds how much of the data is above 2
output_args=nansum(input_args>2)/nanlength(input_args);
%output_args=nansum(input_args>0.3)/nanlength(input_args);
end

