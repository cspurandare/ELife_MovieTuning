function  [L1,L2]=Movie_PlotScatter_PSTH_psychedelic_v3(UnitID,FileName,TCutoff,RVCut,FrameBins,FR_act,FR_shf_mean,FR_shf_std,LocIN,LabelBool,CLR_current,UseAllData)
%For a given cell, plot the scatter of spikes and the FR actual as well as
%the shuffled one
ClrMP=cool(900);
[~,~,~,ST,SI,TBins,RunFreeID,~,~,FrameID]=...
    Allen_VVDot_Get_RunBehavior_Movies([FileName]...
    ,TCutoff,RVCut);
RepCount=ceil((1:54000)/900);
RunFreeID=RunFreeID([1:27000 27002:end]);
if UseAllData
    RunFreeID=true(size(RunFreeID));
end
FrameIDsta=FrameID(RunFreeID );%FrameIDsta=FrameID(RunFreeID);

RepCountsta=RepCount(RunFreeID );%RepCountsta=RepCount(RunFreeID);
TimeCenter=center(TBins);
TimeCenter=TimeCenter([1:27000 27002:end]);
TimeCentersta=TimeCenter(RunFreeID);
if UnitID>1
    STCurrent=ST(SI((UnitID-1))+1:SI((UnitID)));%When does this particular neuron fire
else
    STCurrent=ST(1:SI(1));%When does this particular neuron fire
end

STCurrent=STCurrent(isbetween(STCurrent,TBins(1),TBins(27001)) | isbetween(STCurrent,TBins(27002),TBins(end)));
STCurrent=STCurrent(RunFreeID(nearestpoint(STCurrent,TimeCenter)) );
SpID=nearestpoint(STCurrent,TimeCentersta);

L1=subplot('Position',[LocIN(1),LocIN(2)+LocIN(4)/2+0.01,LocIN(3) LocIN(4)/2]);
if UseAllData
else
    plot(FrameIDsta,RepCountsta,'.','color',[0.9 0.9 0.9],'markersize',1);
end
hold on
if nanmean(FR_act)<4
    
    scatter(FrameIDsta(SpID),RepCountsta(SpID),1,FrameIDsta(SpID),'filled')
    colormap(gca,ClrMP)
else
    scatter(FrameIDsta(SpID),RepCountsta(SpID),1,FrameIDsta(SpID),'filled')
    colormap(gca,ClrMP)
end
axis tight
if LabelBool
    ylabel('Trial #','FontSize',8);
end
%xticks([400 800])
ylim([0 61])
xticks([])
yticks([0 30 60])
ax=gca;ax.YAxis.Color = CLR_current;ax.XAxis.Color = CLR_current;

box off;
L2=subplot('Position',[LocIN(1),LocIN(2),LocIN(3) LocIN(4)/2]);
plot(center(FrameBins),FR_act,'color',CLR_current);
hold on
shadedErrorBar(center(FrameBins),jmm_smooth_1d_cor(FR_shf_mean,2,1),...
    2*jmm_smooth_1d_cor(FR_shf_std,2,1),[0.3 0.3 0.3],1);
if LabelBool
    xlabel('Frame #')
    ylabel('FR (sp/sec)');
end
axis tight;box off
xticks([400 800])
ylim([0 inf])
try
    yticks([0 floor(nanmax(FR_act)*0.75)])
catch
    yticks([0 1])
end
ax=gca;ax.YAxis.Color = CLR_current;
end

