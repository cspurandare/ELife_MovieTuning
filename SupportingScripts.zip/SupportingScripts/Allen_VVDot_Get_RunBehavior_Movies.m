function [ScP,TStart,TEnd,ST,SI,TBins,RunFreeID,RunForW,RV,FrameID,EProp2] = Allen_VVDot_Get_RunBehavior_Movies(fileName,TCutoff,RVCut)
%Give me the session number and the unit, and I will plot the VVDot space scatter

%%Get the running behavior
Beh=CreateBehAllenData2(fileName);
TStart=min(Beh.EyeT);
TEnd=max(Beh.EyeT);
Beh.RunV2=(jmm_smooth_1d_cor(Beh.RunV2,30,1))';%Around 1 second of smoothing

EData=Create_ExperimentEpochs_AllenData2_Movies(fileName,'natural_movie_one_more_repeats_presentations');
TBins=[EData.Start(1:27000);EData.End(27000);EData.Start(27001:54000);EData.End(end)];
TStart=EData.Start(1);TEnd=EData.End(end);
FrameID=EData.Frame;
RV=interp1(Beh.EyeT,Beh.RunV2,center(TBins));RV(27001)=nan;
RunFreeID=GetRunFreeIDs(RV,RVCut,TBins,TCutoff);
RunForW=RV>0;
Acc=jmm_smooth_1d_cor(diff(RV)./diff(center(TBins)),30,1);
AC=interp1(center(center(TBins)),Acc,center(TBins));
ScP=[RV(~RunFreeID & RunForW); AC(~RunFreeID & RunForW)]';

ST = h5read(fileName, '/units/spike_times');%Time of spikes
SI =double( h5read(fileName, '/units/spike_times_index'));% What unit does this spike belong to
%ST=[];
%SI=[];
if nargout>10
EV=interp1(Beh.EyeT,Beh.EyeV,center(TBins));
ESize=interp1(Beh.EyeT,Beh.EyeEllipse(:,1).*Beh.EyeEllipse(:,2),center(TBins));
EP=interp1(Beh.EyeT,Beh.ScreenPos2,center(TBins));
EV_x=diff(jmm_smooth_1d_cor(Beh.ScreenPos2(:,1),10,1))'./diff(Beh.EyeT);EV_x=[EV_x(1);EV_x];
EV_y=diff(jmm_smooth_1d_cor(Beh.ScreenPos2(:,2),10,1))'./diff(Beh.EyeT);EV_y=[EV_y(1);EV_y];
EV2(:,1)=interp1(Beh.EyeT,EV_x,center(TBins));
EV2(:,2)=interp1(Beh.EyeT,EV_y,center(TBins));
EProp2=[ESize  EV EP EV2];
end
end