function [ cor,lags ] = circ_xcorr( input1,input2, scaleopt )
%Take two vectors which are circular, ie input(1)===input(length+1)
%Find xcorr as regular, but taking dot products

if nargin<3
    scaleopt='none';
end

if strcmp(scaleopt,'coeff')
    input1=input1/norm(input1);
    input2=input2/norm(input2);
end


if strcmp(scaleopt,'MAcoeff') %This means mean adjusted coeff normalization
    input1=(input1-nanmean(input1))/norm(input1);
    input2=(input2-nanmean(input2))/norm(input2);
end

if strcmp(scaleopt,'MU&SIGcoeff') %This means mean adjusted coeff normalization
    input1=(input1-nanmean(input1))/(std(input1))/(length(input1)-1);
    input2=(input2-nanmean(input2))/(std(input1))/(length(input2)-1);
end

if strcmp(scaleopt,'corrcoef') %This means mean adjusted coeff normalization
    
end

cor=NaN(length(input1),1);
lags=NaN(length(input1),1);
if length(input1)==length(input2)
    ind=1:2*length(input1)-1;
    lags=ind-length(input1);
    
    for i=ind
       inp=circshift(input2',lags(i)); 
       if strcmp(scaleopt,'corrcoef') %This means mean adjusted coeff normalization
       cor(i)=corrcoefwithNaNDiag(input1,inp');
       else
           cor(i)=dot(input1,inp);
       end
       
    end   
end

end

