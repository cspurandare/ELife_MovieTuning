function [h, hcb] = imagescwithnan(b1,b2,a,cm,nanclr,Position)
% IMAGESC with NaNs assigning a specific color to NaNs
if nargin>5
hcb = colorbar('manual','Position',Position);
else
    hcb = colorbar('southoutside');
end
a(isinf(a))=NaN;
%# find minimum and maximum
amin=nanmin(a(:));
amax=nanmax(a(:));
%# size of colormap
n = size(cm,1);
%# color step
dmap=(amax-amin)/n;

%# standard imagesc
him = imagesc(b1,b2,a);
%# add nan color to colormap
colormap(gca,[nanclr; cm]);
%# changing color limits
try
caxis([amin-dmap amax]);
catch
end
%# place a colorbar
%5colorbar
%# change Y limit for colorbar to avoid showing NaN color
%ylim(hcb,[amin amax])

set(gca,'YDir','normal')

if nargout > 0
    h = him;
end