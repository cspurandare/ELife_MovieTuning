function HAX=BoxPlot_Chinmay(X,Ys,clrIn,ScatterBool)
%Give me the location to plot and the data
if ScatterBool==1
Xs=repmat(X(:),1,size(Ys,1))';
if size(clrIn,1)==1 || isstring(clrIn)
plot(Xs+(0.5*rand(size(Ys))-0.25),Ys,'.','color',clrIn,'markersize',6)
else
plot(Xs+(0.5*rand(size(Ys))-0.25),Ys,'.','color',[0.17 0.17 0.17],'markersize',6)    
end
end
hold on
ym=nanmean(Ys);
ys=nanstd(Ys);
if size(clrIn,1)==1 || isstring(clrIn)
    for i=1:size(Ys,2)
       HAX(i) = line([X(i)-0.4 X(i)+0.4],[ym(i) ym(i)],'Color',clrIn,'Linewidth',2);
        xplot=[X(i)-0.4 X(i)-0.4 X(i)+0.4 X(i)+0.4];
        yplot=[ym(i)-ys(i) ym(i)+ys(i) ym(i)+ys(i) ym(i)-ys(i)];
        patch(xplot,yplot,clrIn,'FaceAlpha',.15);
    end
    
else
    for i=1:size(Ys,2)
       HAX(i) = line([X(i)-0.4 X(i)+0.4],[ym(i) ym(i)],'Color',clrIn(i,:),'Linewidth',2);
        xplot=[X(i)-0.4 X(i)-0.4 X(i)+0.4 X(i)+0.4];
        yplot=[ym(i)-ys(i) ym(i)+ys(i) ym(i)+ys(i) ym(i)-ys(i)];
        patch(xplot,yplot,clrIn(i,:),'FaceAlpha',.15);
    end
end
end

