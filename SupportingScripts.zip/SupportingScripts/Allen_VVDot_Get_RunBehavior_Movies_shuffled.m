function [ScP,TStart,TEnd,ST,SI,TBins,RunFreeID,RunForW,RV,FrameID] = Allen_VVDot_Get_RunBehavior_Movies_shuffled(fileName,TCutoff,RVCut,ShuffledFrameIDs)
%Give me the session number and the unit, and I will plot the VVDot space scatter

%%Get the running behavior
Beh=CreateBehAllenData2(fileName);
TStart=min(Beh.EyeT);
TEnd=max(Beh.EyeT);
Beh.RunV2=(jmm_smooth_1d_cor(Beh.RunV2,30,1))';%Around 1 second of smoothing

EData=Create_ExperimentEpochs_AllenData2_Movies(fileName,'natural_movie_one_shuffled_presentations');
TBins=[EData.Start(1:9000);EData.End(9000);EData.Start(9001:18000);EData.End(end)];
TStart=EData.Start(1);TEnd=EData.End(end);
FrameID=EData.Frame;
FrameID=EData.Frame;
if nargin>3
FrameID=ShuffledFrameIDs(FrameID+1)-1;%Bring this line back to use the    
end

%visual frame IDs as binning variable
%Wont be using this line%FrameID=(FrameID+1);%This variable is just a counter, going from 1 to 899, similar to time from this shuffled movie start
RV=interp1(Beh.EyeT,Beh.RunV2,center(TBins));RV(9001)=nan;
RunFreeID=GetRunFreeIDs(RV,RVCut,TBins,TCutoff);
RunForW=RV>0;
Acc=jmm_smooth_1d_cor(diff(RV)./diff(center(TBins)),30,1);
AC=interp1(center(center(TBins)),Acc,center(TBins));
ScP=[RV(~RunFreeID & RunForW); AC(~RunFreeID & RunForW)]';

ST = h5read(fileName, '/units/spike_times');%Time of spikes
SI =double( h5read(fileName, '/units/spike_times_index'));% What unit does this spike belong to

end