function [SubPlotCounter,s1] = subplot_CSP(in1,in2,in3,SubPlotCounter)
%Helper function to create subplots which are better for publication, and
%takes care of the alphabets as A B etc
if nargin<4;SubPlotCounter=in3;end
p=subplot(in1,in2,in3);s1=get(p,'position');
STR=char(SubPlotCounter + 96); %Change to 64 if you want capital letters, 96 for small
try
annotation('textbox',[s1(1)-s1(3)*0.49 s1(2)+s1(4)*1.15 s1(3)/20 s1(4)/20],'string',STR,'EdgeColor','none','FontSize',18,'FontWeight','bold')
catch
    annotation('textbox',[s1(1)-s1(3)*0.01 s1(2)+s1(4)*1.05 s1(3)/20 s1(4)/20],'string',STR,'EdgeColor','none','FontSize',18,'FontWeight','bold')
end
SubPlotCounter=SubPlotCounter+1;
end

