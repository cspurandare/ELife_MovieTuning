function [ outvec ] = normalizeByMax( vector )
%Just substract mean and divide by the maxima

outvec=(vector)/nanmax(vector);

end
