function y = nanlength(x)
y=sum(~isnan(x));
end