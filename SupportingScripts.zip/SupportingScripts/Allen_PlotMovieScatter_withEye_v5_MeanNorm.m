function  Allen_PlotMovieScatter_withEye_v5_MeanNorm(UnitID,FileName,FR_act,FrameBins,TCutoff,RVCut,RepShuffled,LocIN,LabelBool)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
FrameToTime=linspace(0,30,900);
[~,~,~,ST,SI,TBins,RunFreeID,~,~,FrameID,EProp2]=...
    Allen_VVDot_Get_RunBehavior_Movies([FileName]...
    ,TCutoff,RVCut);


EP=EProp2([1:27000 27002:end],3:4);
Pupil=EProp2([1:27000 27002:end],1);
EV=EProp2([1:27000 27002:end],5:6);
RunFreeID=RunFreeID([1:27000 27002:end]);

EPsta=EP(RunFreeID,:);
Pupilsta=Pupil(RunFreeID,:);
EVsta=EV(RunFreeID,:);
RepCount=ceil((1:54000)/900);

FrameIDsta=FrameID(RunFreeID & RepCount(:)<=RepShuffled);%FrameIDsta=FrameID(RunFreeID);
%FrameIDsta=FrameToTime(FrameIDsta+1);
RepCountsta=RepCount(RunFreeID & RepCount(:)<=RepShuffled);%RepCountsta=RepCount(RunFreeID);
TimeCenter=center(TBins);
TimeCenter=TimeCenter([1:27000 27002:end]);
TimeCentersta=TimeCenter(RunFreeID & RepCount(:)<=RepShuffled);
if UnitID>1
    STCurrent=ST(SI((UnitID-1))+1:SI((UnitID)));%When does this particular neuron fire
else
    STCurrent=ST(1:SI(1));%When does this particular neuron fire
end

STCurrent=STCurrent(isbetween(STCurrent,TBins(1),TBins(27001)) | isbetween(STCurrent,TBins(27002),TBins(end)));
STCurrent=STCurrent(RunFreeID(nearestpoint(STCurrent,TimeCenter)) &  (RepCount(nearestpoint(STCurrent,TimeCenter))<=RepShuffled)');
SpID=nearestpoint(STCurrent,TimeCentersta);

[F1,F2,F3]=GetSpontDataBasedFRPredictionsForEye(UnitID,FileName,FrameBins,TCutoff,RVCut);
%Horizontal scatter
if LabelBool==1;subplot_CSP(LocIN(1,1),LocIN(1,2),LocIN(1,3),1);else;subplot(LocIN(1,1),LocIN(1,2),LocIN(1,3));end
plot(FrameIDsta,EPsta(:,1),'.','color',[0.7 0.7 0.7],'markersize',1);
hold on
plot(FrameIDsta(SpID),EPsta(SpID,1),'r.','markersize',1);
axis tight
box off
if LabelBool
    xlabel('Frame #')
    ylabel('Horizontal gaze ({^o})')
end
%Horizontal Mean rate
if LabelBool==1;subplot_CSP(LocIN(2,1),LocIN(2,2),LocIN(2,3),2);else;subplot(LocIN(2,1),LocIN(2,2),LocIN(2,3));end
hold on
plot(normalizeByMean(F1),'k','linewidth',0.5,'linestyle','-');
yyaxis right;
plot(normalizeByMean(jmm_smooth_1d_cor(FR_act,2,1)),'r','linewidth',1);
if LabelBool
legend('Horizontal gaze - predicted','Observed','orientation','horizontal')
legend boxoff
yyaxis right; ylabel('Firing rate (sp/sec)')
yyaxis left; ylabel('Firing rate (norm.)')
end
box off
axis tight
ax=gca;ax.YAxis(1).Color = 'k';ax.YAxis(2).Color = 'r';
%Vertical scatter
if LabelBool==1;subplot_CSP(LocIN(3,1),LocIN(3,2),LocIN(3,3),3);else;subplot(LocIN(3,1),LocIN(3,2),LocIN(3,3));end
plot(FrameIDsta,EPsta(:,2),'.','color',[0.7 0.7 0.7],'markersize',1);
hold on
plot(FrameIDsta(SpID),EPsta(SpID,2),'m.','markersize',1);
axis tight
box off
if LabelBool
    ylabel('Vertical gaze ({^o})')
end
%Vertical mean rate
if LabelBool==1;subplot_CSP(LocIN(4,1),LocIN(4,2),LocIN(4,3),4);else;subplot(LocIN(4,1),LocIN(4,2),LocIN(4,3));end
hold on
plot(normalizeByMean(F2),'k','linewidth',0.5,'linestyle','-');
yyaxis right;
plot(normalizeByMean(jmm_smooth_1d_cor(FR_act,2,1)),'m','linewidth',1);
if LabelBool
legend('Vertical gaze - predicted','Observed','orientation','horizontal')
legend boxoff
end
box off
axis tight
ax=gca;ax.YAxis(1).Color = 'k';ax.YAxis(2).Color = 'm';
%Pupil area scatter
if LabelBool==1;subplot_CSP(LocIN(5,1),LocIN(5,2),LocIN(5,3),5);else;subplot(LocIN(5,1),LocIN(5,2),LocIN(5,3));end
plot(FrameIDsta,Pupilsta,'.','color',[0.7 0.7 0.7],'markersize',1);
hold on
plot(FrameIDsta(SpID),Pupilsta(SpID),'b.','markersize',1);
axis tight
box off
if LabelBool
    ylabel('Pupil area (a.u.)')
end
%Pupil area mean rate
if LabelBool==1;subplot_CSP(LocIN(6,1),LocIN(6,2),LocIN(6,3),6);else;subplot(LocIN(6,1),LocIN(6,2),LocIN(6,3));end
hold on
plot(normalizeByMean(F3),'k','linewidth',0.5,'linestyle','-');
yyaxis right;
plot(normalizeByMean(jmm_smooth_1d_cor(FR_act,2,1)),'b','linewidth',1);
if LabelBool
legend('Pupil area - predicted','Observed','orientation','horizontal')
legend boxoff
end
box off
axis tight
ax=gca;ax.YAxis(1).Color = 'k';ax.YAxis(2).Color = 'b';

end