function [r,p] = corrcoefwithNaNDiag(x,y)
x=real(x);y=real(y);x=x(:);y=y(:);
good=~isnan(x) & ~isnan(y) & ~isinf(x) & ~isinf(y);
[r,p]=corrcoef(x(good),y(good));
r=r(1,2);p=p(1,2);
end