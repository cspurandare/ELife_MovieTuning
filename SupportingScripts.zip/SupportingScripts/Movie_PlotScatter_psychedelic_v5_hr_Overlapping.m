function  Movie_PlotScatter_psychedelic_v5_hr_Overlapping(UnitID,FileName,TCutoff,RVCut,LabelBool,CLR_current,ScatterSize,FRVec,FrameBins)
%For a given cell, plot the scatter of spikes and the FR actual as well as
%the shuffled one
Upsample=10;
ClrMP=cool(900);
Type=2;
[~,TStart,TEnd,ST,SI,TBins,RunFreeID,~,~,FrameID]=...
    Allen_VVDot_Get_RunBehavior_Movies(FileName...
    ,TCutoff,RVCut);
delTCurrent=nanmedian(diff(TBins));
RepCount=ceil((1:54000)/900);
MovieDataID=zeros(length(center(TBins)),1);MovieDataID([1:27000 27002:length(RunFreeID)])=1;
RunFreeID=RunFreeID(MovieDataID==1);

ValidID=RunFreeID;
FrameIDsta=FrameID(ValidID);%FrameIDsta=FrameID(RunFreeID);


if UnitID>1
    STCurrent=ST(SI((UnitID-1))+1:SI((UnitID)));%When does this particular neuron fire
else
    STCurrent=ST(1:SI(1));%When does this particular neuron fire
end

clearvars FrameIDsta_up FrameIDsta_up_shf RepCountsta_up TBins_up;
cTimeBins=center(TBins);
for h=1:60
    FrameIDsta_up((h-1)*9000+1:h*9000)=-0.4:0.1:899.5;
    RepCountsta_up((h-1)*9000+1:h*9000)=h;
    if h<=30
        TBins_up((h-1)*9000+1:h*9000)=linspace(...
            cTimeBins((h-1)*900+1)-delTCurrent/Upsample*5 ...
            ,cTimeBins((h)*900)+delTCurrent/Upsample*5,9000);
    else
        TBins_up((h-1)*9000+1:h*9000)=linspace(...
            cTimeBins((h-1)*900+2)-delTCurrent/Upsample*5 ...
            ,cTimeBins((h)*900+1)+delTCurrent/Upsample*5,9000);
    end
end

STCurrent=STCurrent(isbetween(STCurrent,TStart,TEnd));
STCurrent=STCurrent(~isbetween(STCurrent,TBins_up(270000),TBins_up(270001)));
FrameCurrent=interp1(TBins_up,FrameIDsta_up,STCurrent);

if Type==1
    plot(FrameCurrent,RepCountsta_up(nearestpoint(STCurrent,TBins_up)),'k.','markersize',ScatterSize)
else
    scatter(FrameCurrent...
        ,RepCountsta_up(nearestpoint(STCurrent,TBins_up)),ScatterSize,...
        FrameIDsta_up(nearestpoint(STCurrent,TBins_up)),'filled')
    colormap(gca,ClrMP)
end

axis tight
if LabelBool
    ylabel('Trial #');
    xlabel('Frame #');
end
ylim([0 61])
%xticks([])
yticks([0 30 60])
hold on
yyaxis right
plot(FrameBins,FRVec,'color',CLR_current,'linewidth',1)
ax=gca;ax.YAxis(1).Color = CLR_current;ax.YAxis(2).Color = CLR_current;
box off
if LabelBool
    ylabel('Firing rate (sp/sec)')
    yyaxis left
    ylabel('Trial #');
    xlabel('Frame #');
end
end

