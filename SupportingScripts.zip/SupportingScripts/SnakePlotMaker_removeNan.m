function [c2,c] = SnakePlotMaker_removeNan(XLab,Matrix,ValueArrange,NormBeforePlot)
%Use a matrix with stacked inputs, which need to be smoothed and normalized
%outside, I will create imagesc with arranged in increasing order of peaks
c2=nan;
NonNan=sum(~isnan(Matrix')) == size(Matrix,2);
Matrix=Matrix(NonNan,:);

if nargin<3
    [~,b]=nanmax(Matrix');[~,c]=sortrows(b');
else
    if length(ValueArrange(NonNan))==size(Matrix,1)
          ValueArrange=ValueArrange(NonNan);
        [c2,c]=sortrows(ValueArrange(:));
    else
        bValue=nanmax(Matrix');[~,c]=sortrows(bValue');
    end
end
if nargin<4
    imagescwithnan(XLab,1:size(Matrix,1),Matrix((c),:),jet,[1 1 1])
else
    imagescwithnan(XLab,1:size(Matrix,1),colNormalizem1p1(Matrix((c),:)),jet,[1 1 1])
end

end
