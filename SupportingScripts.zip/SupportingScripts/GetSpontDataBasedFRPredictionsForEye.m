function [TCfromEyeX,TCfromEyeY,TCfromEyePA] = GetSpontDataBasedFRPredictionsForEye(UnitID,FileName,FrameBins,TCutoff,RVCut)
%Given the sessions location as fileName and the unitid, get eye movement
%data from spontaneuous behavior, during stationary epochs, and estimate
%eye movement relation of firing for the given unit
%------------Eye movements during movie presentation, based predictions
RepShuffled=60;
SMO=2;
[~,~,~,~,~,TBins,RunFreeID,~,~,FrameID,EProp]=...
    Allen_VVDot_Get_RunBehavior_Movies(FileName...
    ,TCutoff,RVCut);
delTCurrent=nanmedian(diff(TBins));
RepCount=ceil((1:54000)/900);
RunFreeID=RunFreeID([1:27000 27002:end]);
EProp=EProp([1:27000 27002:end],:);
FrameIDsta=FrameID(RunFreeID & RepCount(:)<=RepShuffled);%FrameIDsta=FrameID(RunFreeID);
EPropsta=EProp(RunFreeID & RepCount(:)<=RepShuffled,:);%FrameIDsta=FrameID(RunFreeID);
%-----------------------------------------
[~,~,~,ST,SI,TBins,RunFreeID,~,~,~,EProp]=...
    Allen_VVDot_Get_RunBehavior_v2(FileName,delTCurrent...
    ,TCutoff,RVCut);

BinPA=linspace(nanmin(EProp(:,1))-0.1,nanmax(EProp(:,1))+0.1,50 );
BinX=linspace(nanmin(EProp(:,3))-0.1,nanmax(EProp(:,3))+0.1,50 );
BinY=linspace(nanmin(EProp(:,4))-0.1,nanmax(EProp(:,4))+0.1,50 );

if UnitID>1
    STCurrent=ST(SI((UnitID-1))+1:SI((UnitID)));%When does this particular neuron fire
else
    STCurrent=ST(1:SI(1));%When does this particular neuron fire
end
SC=histcounts(STCurrent,TBins);
SC=SC(RunFreeID);
%Create the expected firing profiles
Deno=histcn(EProp(:,1),BinPA);
Temp1=repelem(EProp(:,1),SC);
Num=histcn([Temp1],BinPA);
FRExpectPA=Num./Deno/delTCurrent;

Deno=histcn(EProp(:,3),BinX);
Temp1=repelem(EProp(:,3),SC);
Num=histcn([Temp1],BinX);
FRExpectX=Num./Deno/delTCurrent;

Deno=histcn(EProp(:,4),BinY);
Temp1=repelem(EProp(:,4),SC);
Num=histcn([Temp1],BinY);
FRExpectY=Num./Deno/delTCurrent;

ExpRate=GetExpectedRate1D(FRExpectPA,center(BinPA),EPropsta(:,1));
TCfromEyePA=depHist(ExpRate,FrameIDsta,FrameBins,'given',0,@nanmean,SMO,'none',1);

ExpRate=GetExpectedRate1D(FRExpectX,center(BinX),EPropsta(:,3));
TCfromEyeX=depHist(ExpRate,FrameIDsta,FrameBins,'given',0,@nanmean,SMO,'none',1);

ExpRate=GetExpectedRate1D(FRExpectY,center(BinY),EPropsta(:,4));
TCfromEyeY=depHist(ExpRate,FrameIDsta,FrameBins,'given',0,@nanmean,SMO,'none',1);

end

