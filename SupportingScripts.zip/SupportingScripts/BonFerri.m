function [ Zsc ] = BonFerri( count )
%UNTITLED Summary of this function goes here
%   Applies bonferri correction to Z value for 5per cent cutoff based on
%   count which is the number of multiple counting
 peff=0.025/count;
Zsc=norminv(1-peff);

end

