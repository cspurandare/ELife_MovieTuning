function [Beh] = CreateBehAllenData2(fileName,SMOIN)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
if nargin<2
    SMOIN=20;
end
try
    EyeX = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/center_x');
    EyeY = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/center_y');
    EyeH = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/height');
    EyeW = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/width');
    EyeP = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/phi');
    Beh.EyeT = h5read(fileName, '/processing/eye_tracking/pupil_ellipse_fits/timestamps');
    Beh.EyePos=[EyeX EyeY];
    Beh.EyeEllipse=[EyeH EyeW EyeP];
    Beh.EyeV=RecreateSpeed(Beh.EyePos(:,1),Beh.EyePos(:,2),Beh.EyeT,SMOIN)/1e6;
    Beh.ScreenPos = (h5read(fileName, '/processing/filtered_gaze_mapping/screen_coordinates/data'))';
    
    Beh.ScreenPos2 = (h5read(fileName, '/processing/filtered_gaze_mapping/screen_coordinates_spherical/data'))';
    Beh.ScreenPos3 = (h5read(fileName, '/processing/raw_gaze_mapping/screen_coordinates/data'))';
    Beh.ScreenPos4 = (h5read(fileName, '/processing/raw_gaze_mapping/screen_coordinates_spherical/data'))';
    
    ScreenT = (h5read(fileName, '/processing/filtered_gaze_mapping/screen_coordinates/timestamps'));
    
    RunT = h5read(fileName, '/processing/running/running_speed/timestamps');
    RunV = h5read(fileName, '/processing/running/running_speed/data');
    Beh.RunV2=interp1(RunT,RunV,ScreenT);
    
    Beh.RunV=RunV;
    Beh.RunT=RunT;
    if sum(ScreenT==Beh.EyeT)/length(ScreenT) ==1
    else
        Beh=NaN;
    end
catch
   RunT = h5read(fileName, '/processing/running/running_speed/timestamps');
    RunV = h5read(fileName, '/processing/running/running_speed/data');
    Beh.RunV=RunV;
    Beh.RunT=RunT;
    
end
end

