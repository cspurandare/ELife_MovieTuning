function [ output_args ] = colmaxNormalize( input_args )
%Take mean by columns, and normalize by that
t1=repmat(nanmax(input_args')',1,size(input_args,2));
output_args=(input_args)./t1;

end

