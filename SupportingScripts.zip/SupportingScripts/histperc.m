function [perc, histXout] = histperc( input_args,numOfBins )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
x = input_args(:);
%numOfBins = 100;
if length(numOfBins)==1
[histFreq, histXout] = hist(x, numOfBins);
else
    [histFreq, temp] = histcounts(x, numOfBins);
  histXout=0.5*(temp(1:end-1)+temp(2:end));
end
%figure;
%bar(histXout, histFreq/sum(histFreq)*100);
perc=histFreq/sum(histFreq)*100;
% xlabel('x');
% ylabel('Frequency (percent)');
 %stairs(histXout,perc,'LineWidth',2)
end

